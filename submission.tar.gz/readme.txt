Game: T-REX RUN

If you are a Chrome user, you should be familiar with T-REX RUN. When the Wifi is disconnected from your computer, maybe you spend some time playing this game while waiting for the computer to be connected again. However, if you really want to play this game, do you have to disconnect your computer every time? The answer is NO because you can play this game on the desktop at any time at any place. 

The control flow for T-REX RUN is fairly simple. When you launch your program, you will see the title page (start screen) of the game. Then, you may press <START> (return key on MAC and ENTER key on other computers) to start the game. 

As you press <START>, you will begin the game immediately. Within the game, you can see the score on the top-right corner. You can press <SELECT> (delete key on MAC and backspace on other computers) to go back to the title page. In addition, you are able to control the t-rex. You can press <LEFT> to make t-rex go left by 5 pixels and <RIGHT> to make t-rex go right by 5 pixels. You can press <UP> to make t-rex jump, and t-rex will come back down due to gravity :). The goal of this game is to let t-rex jump over any obstacle, which appears at the right border of the screen and moves in the left direction continuously. 

There is no WINNING condition for this game. When t-rex is hit by the obstacle, you will lose the game, and you will see the LOSE screen. In this screen, you will see your score, and you can press <SELECT> to redirect to the title page to start again. 

I hope that you enjoy this game. Thank you very much!!

By Zhen Jiang 