


// the function used to detect collision between the runner and obstacle
int detectCollision(int trex_runner_row,
                    int trex_runner_col,
                    int trex_runner_width,
                    int trex_runner_height,
                    int obstacle_row,
                    int obstacle_col,
                    int obstacle_width,
                    int obstacle_height);
