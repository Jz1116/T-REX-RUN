/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=21x14 bird bird.png
 * Time-stamp: Friday 04/03/2020, 02:34:08
 *
 * Image Information
 * -----------------
 * bird.png 21@14
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BIRD_H
#define BIRD_H

extern const unsigned short bird_image[294];
#define BIRD_SIZE 588
#define BIRD_LENGTH 294
#define BIRD_WIDTH 21
#define BIRD_HEIGHT 14

#endif
