/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=21x22 runner runner.png
 * Time-stamp: Friday 03/27/2020, 19:29:35
 *
 * Image Information
 * -----------------
 * runner.png 21@22
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RUNNER_H
#define RUNNER_H

extern const unsigned short runner[462];
#define RUNNER_SIZE 924
#define RUNNER_LENGTH 462
#define RUNNER_WIDTH 21
#define RUNNER_HEIGHT 22


#endif
