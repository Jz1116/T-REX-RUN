/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x17 cactus_small cactus_small.png 
 * Time-stamp: Wednesday 04/01/2020, 21:14:15
 * 
 * Image Information
 * -----------------
 * cactus_small.png 8@17
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CACTUS_SMALL_H
#define CACTUS_SMALL_H

extern const unsigned short cactus_small[136];
#define CACTUS_SMALL_SIZE 272
#define CACTUS_SMALL_LENGTH 136
#define CACTUS_SMALL_WIDTH 8
#define CACTUS_SMALL_HEIGHT 17

#endif

