/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=12x24 cactus_big cactus_big.png
 * Time-stamp: Wednesday 04/01/2020, 19:39:59
 *
 * Image Information
 * -----------------
 * cactus_big.png 12@24
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CACTUS_BIG_H
#define CACTUS_BIG_H

extern const unsigned short cactus_big[288];
#define CACTUS_BIG_SIZE 576
#define CACTUS_BIG_LENGTH 288
#define CACTUS_BIG_WIDTH 12
#define CACTUS_BIG_HEIGHT 24


#endif
